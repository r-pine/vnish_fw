ENGLISH:

1.Download the etcher program to record the SD image https://www.balena.io/etcher or https://rufus.ie/en/
2.Run the etcher program and select the image for your asic model with the .img extension
3.Write the image to the SD card (the SD card must be not more than 32 GB, FAT32 format)
4.Insert the SD card with the VNISH image into ASIC, turn on ASIC, the VNISH firmware is installed if you pull out the SD-the card, the BITMAIN firmware will return.





