ENGLISH:

1.Download the etcher program to record the SD image https://www.balena.io/etcher or https://rufus.ie/en/
2.Run the etcher program and select the image for your asic model with the .img extension
3.Write the image to the SD card (the SD card must be not more than 32 GB, FAT32 format)
4.Insert the SD card with the VNISH image into ASIC, turn on ASIC, the VNISH firmware is installed if you pull out the SD-the card, the BITMAIN firmware will return.




РУССКИЙ:

1.Cкачиваем программу etcher для записи SD образа  https://www.balena.io/etcher или https://rufus.ie/ru/
2.Запускаем программу etcher и выбираем образ под вашу модель асика с расширением .img
3.Записываем образ на SD карту (SD карта должна быть обьемом не более 32 гб , формат FAT32)
4.Вставляем SD карту с образом VNISH в асик, включаем асик, прошивка VNISH установлена, если вы вытащите SD-карту, вернется прошивка BITMAIN.




中国人:

1. 下载 etcher 程序来录制 SD 图像 https://www.balena.io/etcher 或 https://rufus.ie/ru/
2. 启动 etcher 程序并为您的 ASIC 模型选择一个扩展名为 .img 的镜像
3. 将镜像写入SD卡（SD卡大小不得超过32GB，FAT32格式）
4. 将带有 VNISH 镜像的 SD 卡插入 ASIC，打开 ASIC，VNIISH 固件已安装，如果拔出 SD 卡，BITMAIN 固件将恢复。

