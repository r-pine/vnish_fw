#!/bin/sh

if [ -x /etc/init.d/S49dashd ]; then
    DASHD=/etc/init.d/S49dashd
elif [ -x /etc/init.d/S80dashd ]; then
    DASHD=/etc/init.d/S80dashd
fi

echo "stopping anthill services"
/etc/init.d/S15timezone stop
/etc/init.d/S12hwscan stop
/etc/init.d/S71monitor stop
/etc/init.d/S70miner stop
/etc/init.d/S99agent stop
[ -n "$DASHD" ] && "$DASHD" stop

echo "extracting overlay files"
tar -xzf /nvdata/anthillos/overlay.tar.gz -C /

echo "starting anthill services"
/etc/init.d/S15timezone start
/etc/init.d/S12hwscan start
[ -n "$DASHD" ] && "$DASHD" start
/etc/init.d/S70miner start
/etc/init.d/S71monitor start
/etc/init.d/S99agent start
